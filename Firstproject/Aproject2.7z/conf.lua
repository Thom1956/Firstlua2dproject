function love.conf(t)
  t.window.height=600
  t.window.width=800
  end